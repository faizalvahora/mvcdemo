﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebApplication1.DbContext;
namespace WebApplication1.DbContext
{
    public class FormAuth
    {
        public string checklogin(checkLogin checklogin)
        {
            string Result = string.Empty;
            using (dbEntities db = new dbEntities())
            {
                var objdata = (db.AspNetUsers.Where(x => x.Email == checklogin.Username).FirstOrDefault());
                
            }
            return Result;
        }
    }
    public class checkLogin
    {
        public string Username { get; set; }
        public string Password { get; set; } 
    }
}