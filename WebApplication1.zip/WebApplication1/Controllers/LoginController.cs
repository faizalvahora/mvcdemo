﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Common;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {           
                return View();
        }
        [HttpPost]
        public ActionResult Index(Index model)
        {
            using (ADOHelper db = new ADOHelper())
            {
                DataSet ds = new DataSet();
                ds = (db.ExecDataSet("select * from logintbl where username=@email", "@email", model.email));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string pas=ds.Tables[0].Rows[0]["Password"].ToString();
                    
                }
            }
            return View();
        }
    }
}